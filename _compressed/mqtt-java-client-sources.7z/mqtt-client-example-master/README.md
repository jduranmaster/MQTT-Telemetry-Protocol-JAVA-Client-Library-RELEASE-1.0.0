MQTT-Client-Example
===================

[MQTT](http://mqtt.org) publisher/subscriber example implemented using [Eclipse Paho](http://www.eclipse.org/paho/) client libraries.

This is tested against the publicly hosted [Mosquitto](http://mosquitto.org) Broker on http://test.mosquitto.org (on port 1883).

References: http://www.infoq.com/articles/practical-mqtt-with-paho
